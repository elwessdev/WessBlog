<footer>
  <div class="container-xl">
    <div class="footer-inner">
      <div class="row d-flex align-items-center gy-4">
        <h3 class="copyright">© 2024 WessBlog</h3>
        <!-- <div class="col-md-4 text-center">
          <ul class="social-icons list-unstyled list-inline mb-0">
            <li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
            <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li class="list-inline-item"><a href="#"><i class="fab fa-instagram"></i></a></li>
            <li class="list-inline-item"><a href="#"><i class="fab fa-pinterest"></i></a></li>
            <li class="list-inline-item"><a href="#"><i class="fab fa-medium"></i></a></li>
            <li class="list-inline-item"><a href="#"><i class="fab fa-youtube"></i></a></li>
          </ul>
        </div> -->
        <!-- <button class="backTop">Back to Top</button> -->
      </div>
    </div>
  </div>
</footer>